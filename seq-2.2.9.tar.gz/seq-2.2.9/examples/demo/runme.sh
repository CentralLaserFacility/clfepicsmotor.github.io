#!/bin/sh
./O.$EPICS_HOST_ARCH/demo demo.stcmd
