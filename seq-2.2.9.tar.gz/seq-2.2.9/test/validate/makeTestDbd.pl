foreach my $x (@ARGV) {
  print "registrar(${x}TestRegistrar)\n"
}
